<?php
// Heading
$_['heading_title']        = 'Prix d\'estimation d\'expédition &amp; Taxes';

// Text
$_['text_shipping_method'] = 'Options des méthodes d\'expédition';
$_['text_destination']     = 'Entrez votre destination pour obtenir une estimation d\'expédition.';
$_['text_estimate']        = 'Veuillez svp sélectionner le mode d\'expédition que vous préférez sur cette commande.';
$_['text_success']         = 'Succès: Votre estimation d\'expédition a été appliquée!';

// Entry
$_['entry_country']        = 'Pays';
$_['entry_zone']           = 'Région / Province';
$_['entry_postcode']       = 'Code Postal';

// Error
$_['error_postcode']       = 'Le code postal doit contenir entre 2 à 10 caractères!';
$_['error_country']        = 'Veuillez sélectionner un pays!';
$_['error_zone']           = 'Veuillez sélectionner une région / province!';
$_['error_shipping']       = 'Attention: La méthode d\'expédition est requise!';
$_['error_no_shipping']    = 'Attention: Aucune option d\'expédition n\'est disponible. Veuillez nous <a href="%s">contacter</a> pour obtenir de l\'assistance!';
