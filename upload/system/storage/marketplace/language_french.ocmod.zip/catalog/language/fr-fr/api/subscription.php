<?php
// Text
$_['text_success']           = 'Succès: Vous avez modifié les abonnements!';

// Error
$_['error_customer']           = 'Attention: Les détails du client sont requis!';
$_['error_payment_address']    = 'Attention: L\'adresse de facturation est requise!';
$_['error_payment_method']     = 'Attention: La méthode de paiement est requise!';
$_['error_shipping_address']   = 'Attention: L\'adresse d\'expédition est requise!';
$_['error_shipping_method']    = 'Attention: La méthode d\'expédition est requise!';
$_['error_product']            = 'Attention: Des produits sont requis!';
$_['error_stock']              = 'Attention: Les produits marqués avec *** ne sont pas disponibles dans la quantité souhaitée ou ne sont pas en stock!';
$_['error_minimum']            = 'Attention: Le montant minimum de commande pour %s est %s!';
$_['error_subscription']       = 'Attention: Un abonnement est requis!';
$_['error_subscription_plan']  = 'Attention: Un plan d\'abonnement est requis!';
$_['error_call']               = 'La requête API est introuvable';
