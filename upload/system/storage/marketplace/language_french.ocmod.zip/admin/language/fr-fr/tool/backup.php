<?php
// Heading
$_['heading_title']      = 'Sauvegarde &amp; Restauration';

// Text
$_['text_success']       = 'Succès: Vous avez modifié votre base de données avec succès!';
$_['text_progress']      = 'Progression';
$_['text_backup']        = 'Sauvegarde de la table %s, enregistrements %s à %s';
$_['text_restore']       = 'Restauration %s sur %s';
$_['text_option']        = 'Options de sauvegarde';
$_['text_history']       = 'Historique des sauvegardes';
$_['text_import']        = 'Pour les fichiers de sauvegarde volumineux, il est préférable de télécharger le fichier SQL via FTP dans le répertoire <strong>~/storage/backup/</strong>.';

// Column
$_['column_filename']    = 'Nom du fichier';
$_['column_size']        = 'Taille';
$_['column_date_added']  = 'Date d\'ajout';
$_['column_action']      = 'Action';

// Entry
$_['entry_progress']     = 'Progression';
$_['entry_export']       = 'Exporter';

// Error
$_['error_permission']   = 'Attention: Vous n\'avez pas la permission de modifier la sauvegarde &amp; restauration!';
$_['error_table']        = 'La table %s n\'est pas dans la liste autorisée!';
$_['error_file']         = 'Le fichier est introuvable!';
$_['error_directory']    = 'Le répertoire est introuvable!';
$_['error_not_found']    = 'Erreur: Impossible de trouver le fichier %s!';
$_['error_headers_sent'] = 'Erreur: Les en-têtes ont déjà été envoyés!';
$_['error_upload_size']  = 'Le fichier téléchargé ne peut pas dépasser %s!';
